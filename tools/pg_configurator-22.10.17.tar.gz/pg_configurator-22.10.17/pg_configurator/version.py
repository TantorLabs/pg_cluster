"""pg_configurator version information."""

__version__ = "22.10.17"
